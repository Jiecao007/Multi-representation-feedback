# V1

Download and extract `V1.zip`, then open `V1/index.html` in a browser.

Includes P1–P4 original interaction HTML and a prompt page with exact archived templates, expanded profiles/prior, and actual system instructions. All pages work offline.

Source: `simulated_students_current_20261028T035633Z_p1_p4_english`. Original version: `pv1-28ac7c4431735404`. Saved interactions and prompt text are preserved; this is a presentation package, not a new experiment.
